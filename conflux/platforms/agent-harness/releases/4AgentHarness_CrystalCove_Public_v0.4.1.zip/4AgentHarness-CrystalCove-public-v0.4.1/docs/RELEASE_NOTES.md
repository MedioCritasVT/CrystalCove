# v0.4.1-public — packaging changes relative to local v0.4

- Bundled the working v0.4 controller/worker/Podman architecture without the archive's historical `original/` copies or local runtime data.
- Added a read-only SQL inspector (`./sql.sh` and `scripts/sql_readonly.py`) for the existing shared SQLite board; **no schema migration or database writes**.
- Added `examples/fts5_demo.py` using in-memory fabricated content to demonstrate a possible future RAG retrieval surface.
- Mapped Open WebUI MedioCritas export to **sanitized** persona prompt (`examples/mediocritas.system.md`) and illustrative JSON settings, omitting account-specific IDs, embedded image data, and unverified capability toggles.
- Added top_p, top_k, and repeat_penalty environment options for Ollama worker requests. Default Node 1 temperature set to 0.75 as in the supplied Medio example; other workers remain 0.70.
- Made Ollama's *initial* parallelism configurable with `VOS_OLLAMA_PARALLEL`, default 1; keeps `VOS_OLLAMA_MAX_LOADED_MODELS=1` by default. These settings do not retroactively change an existing Ollama container.
- Added honest status/roadmap documents describing Git, SQL, RabbitMQ, future retrieval, agent-specific private memory, and VOS/game connectors.
- **No additional agent tool permissions.** The agent's `post_note`, `read_notes`, `ask_node` are unchanged. SQL is available only to the local operator, not to an LLM.

**Testing:** Python syntax, shell syntax, SQL read-only tests, source inspections, and previous mocked harness regression tests can be run locally. A public deployment requires real Podman/Ollama/GPU/Open WebUI and agent-tool acceptance tests on the target machine.
