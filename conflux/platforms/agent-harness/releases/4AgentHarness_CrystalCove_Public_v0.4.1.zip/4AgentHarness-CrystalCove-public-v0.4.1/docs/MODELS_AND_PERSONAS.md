# Model parameters and agent persona settings

## Model parameters: effective settings vs UI selections

The custom Open WebUI Pipe relays text conversation turns to the VOS controller. **It does not forward arbitrary Open WebUI Advanced Params to the Ollama worker.** Therefore setting parameters on a workspace model does **not** guarantee they affect inference in the harness.

Worker settings come from `agents/node1.env` ... `node4.env`; change them and run `./vos.sh recreate-node N` to apply. Model weights are served by a single Ollama container. The local Pipe is text-only: selecting `vision`, `terminal`, `file upload`, `knowledge`, `web search`, `code interpreter` or `memory` metadata in Open WebUI does not automatically grant equivalent harness tools.

| Setting | Node 1 (Medio example) | Nodes 2–4 (starting point) | Worker env |
| --- | --- | --- | --- |
| Model | qwen3.5:4b | Node 2: 4B; Nodes 3–4: 9B | `VOS_MODEL` |
| Context | 16,000 | 16,000 | `VOS_NUM_CTX` |
| Max generation | 3,000 | 3,000 | `VOS_NUM_PREDICT` |
| Temperature | 0.75 | 0.70 | `VOS_TEMPERATURE` |
| Top P | 0.90 | 0.90 | `VOS_TOP_P` |
| Top K | 40 | 40 | `VOS_TOP_K` |
| Repeat penalty | 1.05 | 1.05 | `VOS_REPEAT_PENALTY` |
| Reasoning | true | true | `VOS_THINK` |
| Tool calling | Controller sends bounded tool schemas | same | Not a switch; actual tool calls are checked |
| Streaming | No (Pipe waits for results) | No | Fixed in worker |

The Ollama model may consume part of the token budget on reasoning. The harness currently passes these sampling options to Ollama; it does not pass an arbitrary advanced-param dictionary from Open WebUI.

## Concurrent agents

Each worker is a separate container and can take work, but **Ollama defaults to one active inference slot** in this package to reduce VRAM contention.

For a brand new install on a machine with sufficient available VRAM/RAM:

```bash
VOS_OLLAMA_PARALLEL=2 VOS_OLLAMA_MAX_LOADED_MODELS=1 ./install.sh
```

Two requests can share the same 4B model weights while retaining separate conversations, but a 16K context on each request requires additional KV cache. 4B + 9B loaded together is deliberately *not* the default. **These environment variables only affect an Ollama container when first created.** Do not recreate the existing Ollama container without preserving its named volume and documenting the change. Always inspect memory use and test on the actual host.

## Persona example

- `examples/mediocritas.system.md` — copied persona system text from a user-provided MedioCritas export.
- `examples/mediocritas.settings.example.json` — **sanitized sample**, not guaranteed importable JSON. It excludes account IDs, internal version IDs, timestamps, embedded base64 imagery, and declared capabilities that have not been verified.

To use the example, create an Open WebUI custom model based on **VOS Node 1** and paste the system text and optional params into the editor. The persona name and prompt are not permissions, and do not substitute for memory retrieval or tool receipts. The four slots can be assigned other personas; the five Conflux narrative Nodes do not imply five working local containers.

## Verify

Use `./vos.sh ask 1 'State your available tools and limitations.'` and inspect a deliberate `post_note` + `read_notes` test. For an exact runtime check, inspect the running worker's environment and Ollama logs locally. Do not claim direct Python, shell, host files, or RAG access solely from the model's claims or Open WebUI UI toggles.
