# Conflux / CrystalCove — Four-Agent Harness (public preview)

**Package:** v0.4.1-public, 12 November 2026  
**Application compatibility:** VOS harness v0.4, four RabbitMQ workers, SQLite shared board, Open WebUI Pipe, Ollama models.  
**Status:** local-development preview; **not** an operational VOS/game connector or production-ready hosted service.

Four independent *request routes* through Podman containers, using a shared Ollama inference server. People can experiment with agent personas, bounded tools, a shared SQL-backed note board, and peer question routing. This package is an optional local developer companion to the [CrystalCove project](https://github.com/MedioCritasVT/CrystalCove), not part of the downloadable Unreal game.

## First-time users

1. Use a Linux machine with Podman and Python 3, plus adequate disk and RAM. GPU support is optional; NVIDIA users need working Podman CDI. Review [deployment requirements](docs/DEPLOYMENT_V04.md) and the [security notes](docs/SECURITY_AND_PUBLISHING.md).
2. Unzip this package and open a terminal in the extracted folder.
3. Run `./install.sh`. It provisions four separate agent images, controller, RabbitMQ, Ollama and Open WebUI, then downloads Qwen3.5 4B and 9B.
4. Visit <http://127.0.0.1:3001>, create your own Open WebUI admin account and enable admin API keys if necessary.
5. Run `./vos.sh import-pipe` and enter your locally generated Open WebUI admin API key. This is **not** the VOS controller token; the import script reads that separately from `.local/`.
6. Choose **VOS Node 1–4** in the chat model picker, or create your own workspace model based on one of them. See [personalization](docs/MODELS_AND_PERSONAS.md).
7. Verify each agent with `./verify.sh`, `./vos.sh ask 1 'Say hello.'`, and a `post_note` + `read_notes` exchange. **Read tool receipts rather than trusting textual success claims.**

**Existing v0.4 users:** Do **not** run `install.sh` in a second directory expecting it to transfer your `.local/` credentials. Existing named volumes and containers use the same v0.4 identity. Keep the original working installation and its `.local/` directory; back up data before updating scripts or recreating nodes. A copied source tree does not copy your Podman volumes or Open WebUI users/personas.

## Daily commands

| Command | What it does |
| --- | --- |
| `./start.sh` / `./stop.sh` | Start or stop the local stack; never deletes volumes |
| `./verify.sh` | Check container and service readiness (not LLM accuracy) |
| `./vos.sh status` | Show container states |
| `./vos.sh ask 1 'hello'` | Exercise Node 1 through the actual controller and worker |
| `./vos.sh board` | Show shared notes through controller API |
| `./vos.sh receipts` | Show recorded tool execution receipts |
| `./sql.sh` | **Read-only SQL** view of the latest shared notes |
| `./sql.sh 'SELECT node, count(*) AS n FROM notes GROUP BY node'` | Read-only SQL aggregation |
| `python3 examples/fts5_demo.py` | Try SQLite text retrieval in memory (no live DB writes) |

## What is real and what is planned?

| Feature | Status |
| --- | --- |
| Four Podman agent workers and one Ollama inference endpoint | Implemented; host verification required |
| Shared SQLite `notes` + `events` tables | Implemented |
| Tools `post_note`, `read_notes`, `ask_node` | Implemented with execution receipts |
| Read-only local SQL inspector | **New in this public packaging** |
| Per-agent private persistent memory | **Planned only; no private-memory tool or isolation guarantee yet** |
| RAG over indexed project files | **Planned; sample FTS5 demonstration only** |
| VOS service gateway, telemetry and approvals | **Planned; not connected** |
| Unreal game event bridge / in-game Node dialogue | **Planned; not connected** |
| Independent two-perspective deliberation workflow | **Proposed; no workflow executor shipped** |

## Documentation

- [Detailed v0.4 deployment guide](docs/DEPLOYMENT_V04.md)
- [Model parameters and persona examples](docs/MODELS_AND_PERSONAS.md)
- [SQL, RabbitMQ, Git, and RAG: distinct jobs](docs/SQL_RABBITMQ_RAG.md)
- [VOS and game integration plan](docs/VOS_GAME_ROADMAP.md)
- [Public safety, migration and release checklist](docs/SECURITY_AND_PUBLISHING.md)
- [What changed](docs/RELEASE_NOTES.md)

### Compatibility and licensing

The runtime retains **v0.4 container names and labels** so this public packaging does not create parallel stacks or overwrite unrelated legacy v0.3 installations. The additional `.env` sampling options only apply when agent containers are recreated. For a fresh installation the defaults are loaded on creation. Ollama concurrency defaults to one inference slot; two-slot mode is opt-in **before first installation**, subject to hardware capacity.

The CrystalCove repository had no root `LICENSE` file when this package was prepared. **Choose and add an explicit license before telling contributors they may freely redistribute or modify this project.** This bundle includes no paid/private model weights, personal conversation archives, API keys, or Open WebUI account identifiers. Upstream container images and software retain their own licensing terms.
