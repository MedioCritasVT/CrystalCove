#!/usr/bin/env python3
"""Opt-in local Open WebUI Pipe import after first-admin signup.

Never stores the admin API key. Uses a dedicated controller token read from the
local credential file. Not needed for direct CLI use.
"""
import getpass
import json
import os
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
FUNCTION_ID = "conflux_vos_v04"
HOST = "http://127.0.0.1:" + os.environ.get("VOS_WEBUI_PORT", "3001")


def request(path: str, token: str, method: str = "GET", payload=None):
    headers = {"Authorization": "Bearer " + token, "Accept": "application/json"}
    body = None
    if payload is not None:
        body = json.dumps(payload).encode()
        headers["Content-Type"] = "application/json"
    req = Request(HOST + path, data=body, headers=headers, method=method)
    with urlopen(req, timeout=30) as response:
        contents = response.read().decode()
        return json.loads(contents) if contents else None


def main():
    secrets_file = ROOT / ".local/controller.env"
    if not secrets_file.exists():
        raise SystemExit("Install first; .local/controller.env is missing.")
    controller_token = next((line.split("=", 1)[1].strip() for line in secrets_file.read_text().splitlines()
                             if line.startswith("VOS_HARNESS_TOKEN=")), "")
    if not controller_token:
        raise SystemExit("Missing dedicated harness token.")
    print("Importing local Conflux Pipe into:", HOST)
    print("Sign in to Open WebUI, create an admin API key, then enter it here.")
    token = os.environ.get("WEBUI_API_TOKEN") or getpass.getpass("Admin Open WebUI API key (hidden): ")
    if not token:
        raise SystemExit("No API key supplied.")
    try:
        listed = request("/api/v1/functions/", token)
    except HTTPError as err:
        raise SystemExit(f"Cannot list Functions: HTTP {err.code}. Check the admin API key.") from err
    if any(record.get("id") == FUNCTION_ID for record in (listed or [])):
        raise SystemExit("Function conflux_vos_v04 already exists; refusing to overwrite custom code. "
                         "Edit or delete it in Admin > Functions before importing again.")
    source = (ROOT / "openwebui_vos_pipe.py").read_text(encoding="utf-8")
    record = {
        "id": FUNCTION_ID,
        "name": "Conflux VOS v0.4 — four agents",
        "type": "pipe",
        "content": source,
        "meta": {"description": "Four RabbitMQ-routed VOS agents with receipt-backed local tools"},
    }
    try:
        request("/api/v1/functions/create", token, "POST", record)
        request(f"/api/v1/functions/id/{FUNCTION_ID}/valves/update", token, "POST", {
            "HARNESS_URL": "http://conflux_v04_controller:8080",
            "HARNESS_TOKEN": controller_token,
            "TIMEOUT_SECONDS": 960,
        })
        info = request(f"/api/v1/functions/id/{FUNCTION_ID}", token)
        if not info or not info.get("is_active", False):
            request(f"/api/v1/functions/id/{FUNCTION_ID}/toggle", token, "POST")
        print("Pipe installed and enabled. Refresh Open WebUI to select VOS Node 1–4.")
    except (HTTPError, URLError) as err:
        detail = ""
        if isinstance(err, HTTPError):
            detail = err.read().decode(errors="replace")[:600]
        raise SystemExit(f"Import incomplete: {err}. {detail}\nUse the manual import instructions in README.md.") from err


if __name__ == "__main__":
    main()
