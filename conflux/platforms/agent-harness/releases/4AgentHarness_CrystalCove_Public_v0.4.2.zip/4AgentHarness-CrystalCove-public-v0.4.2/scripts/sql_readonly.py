#!/usr/bin/env python3
"""Read-only SQLite inspection utility for the local Conflux VOS shared board.

Intended for invocation by sql.sh inside the controller container or directly
against a COPY of board.sqlite3. No database schema changes or writes.
"""
import json
import os
from pathlib import Path
import re
import sqlite3
import sys

DEFAULT = "SELECT id, created_at, node, text FROM notes ORDER BY id DESC LIMIT 10"
MAX_RETURNED_ROWS = 100


def run(query, database_path):
    if not re.match(r'^\s*(SELECT|WITH)\b', query, flags=re.I):
        raise ValueError('Read-only SELECT/CTE queries only. No PRAGMA, INSERT, UPDATE, DELETE or DDL.')
    path = Path(database_path).resolve(strict=True)
    conn = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=5)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA query_only=ON')
        cur = conn.execute(query)
        rows = cur.fetchmany(MAX_RETURNED_ROWS + 1)
        return {'columns': [col[0] for col in cur.description],
                'rows': [dict(r) for r in rows[:MAX_RETURNED_ROWS]],
                'truncated': len(rows) > MAX_RETURNED_ROWS,
                'read_only': True}
    finally:
        conn.close()


def main():
    query = sys.argv[1] if len(sys.argv)>1 else DEFAULT
    try:
        print(json.dumps(run(query, os.getenv('VOS_BOARD_DB','/data/board.sqlite3')),
                         indent=2, ensure_ascii=False))
    except (OSError, sqlite3.Error, ValueError) as exc:
        print('SQL inspection error: '+str(exc), file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
