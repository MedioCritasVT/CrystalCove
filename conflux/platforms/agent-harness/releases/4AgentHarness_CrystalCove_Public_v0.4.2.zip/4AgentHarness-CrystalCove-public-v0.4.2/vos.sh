#!/usr/bin/env bash
# Standalone v0.4 deployment; does not modify the legacy v0.2/v0.3 installation.
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
PROJECT='conflux_v04'
NETWORK="${PROJECT}_net"
BROKER="${PROJECT}_rabbitmq"
OLLAMA="${PROJECT}_ollama"
WEBUI="${PROJECT}_webui"
CONTROLLER="${PROJECT}_controller"
BASE_IMAGE='localhost/conflux-v04-base:0.4'
CONTROLLER_IMAGE='localhost/conflux-v04-controller:0.4'
OLLAMA_IMAGE="${OLLAMA_IMAGE:-docker.io/ollama/ollama:latest}"
WEBUI_IMAGE="${WEBUI_IMAGE:-ghcr.io/open-webui/open-webui:main}"
RABBIT_IMAGE="${RABBIT_IMAGE:-docker.io/library/rabbitmq:4-management}"
WEBUI_PORT="${VOS_WEBUI_PORT:-3001}"
RABBIT_PORT="${VOS_RABBIT_PORT:-15672}"
mkdir -p .local
chmod 700 .local

info() { printf '%s\n' "[conflux-v04] $*"; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
require() { command -v "$1" >/dev/null 2>&1 || fail "Missing $1. Install it and run this command again."; }
exists() { podman container exists "$1"; }
image_for() { printf 'localhost/conflux-v04-agent-%s:0.4' "$1"; }
worker_for() { printf '%s_worker_%s' "$PROJECT" "$1"; }
volume() { podman volume exists "$1" || podman volume create "$1" >/dev/null; }
network() { podman network exists "$NETWORK" || podman network create "$NETWORK" >/dev/null; }
randhex() { python3 -c 'import secrets; print(secrets.token_hex(32))'; }
ensure_secrets() {
  require python3
  umask 077
  if [[ ! -f .local/rabbit.env || ! -f .local/worker.env || ! -f .local/controller.env ]]; then
    # Partial credentials may belong to existing volumes; refuse to rotate accidentally.
    if [[ -f .local/rabbit.env || -f .local/worker.env || -f .local/controller.env ]]; then
      fail 'Partial credential files found in .local/. Restore the missing files; refusing to rotate secrets.'
    fi
    if podman volume exists "${PROJECT}_rabbit_data"; then
      fail 'Existing RabbitMQ volume found but credentials are missing. Restore .local/ (do not generate new passwords over existing data).'
    fi
    local broker_password controller_token
    broker_password="$(randhex)"; controller_token="$(randhex)"
    printf 'RABBITMQ_DEFAULT_USER=vos_worker\nRABBITMQ_DEFAULT_PASS=%s\n' "$broker_password" >.local/rabbit.env
    printf 'VOS_RABBIT_HOST=%s\nVOS_RABBIT_USER=vos_worker\nVOS_RABBIT_PASSWORD=%s\n' "$BROKER" "$broker_password" >.local/worker.env
    printf 'VOS_HARNESS_TOKEN=%s\n' "$controller_token" >.local/controller.env
    chmod 600 .local/*.env
    info 'Generated private credentials in .local/. Back them up securely along with your volumes.'
  fi
}
managed() {
  local name="$1" label
  if exists "$name"; then
    label="$(podman inspect --format '{{index .Config.Labels "io.conflux.stack"}}' "$name" 2>/dev/null || true)"
    [[ "$label" == 'v0.4' ]] || fail "Container $name exists but is not labelled as this deployment. Not touching it."
    return 0
  fi
  return 1
}
start_existing() {
  local name="$1"
  if managed "$name"; then
    if [[ "$(podman inspect --format '{{.State.Running}}' "$name")" != true ]]; then podman start "$name" >/dev/null; fi
    return 0
  fi
  return 1
}
stop_existing() {
  if managed "$1"; then podman stop --ignore "$1" >/dev/null; fi
}
wait_broker() {
  local i
  for i in {1..60}; do
    if podman exec "$BROKER" rabbitmq-diagnostics -q check_running >/dev/null 2>&1; then return 0; fi
    sleep 2
  done
  podman logs --tail 30 "$BROKER" >&2 || true
  fail 'RabbitMQ did not become ready.'
}
wait_ollama() {
  local i
  for i in {1..60}; do
    if podman exec "$OLLAMA" ollama list >/dev/null 2>&1; then return 0; fi
    sleep 2
  done
  podman logs --tail 30 "$OLLAMA" >&2 || true
  fail 'Ollama did not become ready.'
}
gpu_flag() {
  local mode="${VOS_GPU:-auto}"
  [[ "$mode" == auto || "$mode" == nvidia || "$mode" == cpu ]] || fail 'Set VOS_GPU to auto, nvidia, or cpu.'
  if [[ "$mode" == cpu ]]; then echo cpu; return; fi
  if command -v nvidia-smi >/dev/null 2>&1 && command -v nvidia-ctk >/dev/null 2>&1 \
      && nvidia-ctk cdi list 2>/dev/null | grep -q 'nvidia.com/gpu=all'; then
    echo nvidia; return
  fi
  if [[ "$mode" == nvidia ]]; then
    fail 'GPU requested, but NVIDIA CDI not detected. Configure NVIDIA Container Toolkit CDI first (see README).'
  fi
  info 'NVIDIA CDI was not detected; running Ollama on CPU. Set VOS_GPU=nvidia once CDI works.' >&2
  echo cpu
}

build_images() {
  info 'Building a shared base image, one controller image and four separate agent images.'
  podman build -t "$BASE_IMAGE" -f Containerfile.base .
  podman build -t "$CONTROLLER_IMAGE" -f Containerfile.controller .
  local n model
  for n in 1 2 3 4; do
    model="$(sed -n 's/^VOS_MODEL=//p' "agents/node$n.env" | head -n 1)"
    [[ -n "$model" ]] || fail "Missing VOS_MODEL in agents/node$n.env"
    podman build --build-arg "NODE=$n" --build-arg "MODEL=$model" -t "$(image_for "$n")" -f Containerfile.agent .
  done
}
launch_broker() {
  if start_existing "$BROKER"; then return; fi
  volume "${PROJECT}_rabbit_data"
  podman run -d --name "$BROKER" --hostname cfx4-rabbit --label io.conflux.stack=v0.4 \
    --network "$NETWORK" --security-opt=no-new-privileges \
    -p "127.0.0.1:${RABBIT_PORT}:15672" \
    --env-file .local/rabbit.env -v "${PROJECT}_rabbit_data:/var/lib/rabbitmq" \
    "$RABBIT_IMAGE" >/dev/null
}
launch_ollama() {
  if start_existing "$OLLAMA"; then return; fi
  volume "${PROJECT}_ollama_data"
  local gpu; gpu="$(gpu_flag)"
  local -a opts=()
  if [[ "$gpu" == nvidia ]]; then opts+=(--device nvidia.com/gpu=all --security-opt=label=disable); fi
  podman run -d --name "$OLLAMA" --label io.conflux.stack=v0.4 --network "$NETWORK" \
    --security-opt=no-new-privileges "${opts[@]}" \
    -e OLLAMA_HOST=0.0.0.0:11434 \
    -e OLLAMA_CONTEXT_LENGTH=16000 \
    -e OLLAMA_MAX_LOADED_MODELS="${VOS_OLLAMA_MAX_LOADED_MODELS:-1}" \
    -e OLLAMA_NUM_PARALLEL="${VOS_OLLAMA_PARALLEL:-1}" \
    -e OLLAMA_MAX_QUEUE="${VOS_OLLAMA_MAX_QUEUE:-16}" \
    -e OLLAMA_KEEP_ALIVE=2m \
    -v "${PROJECT}_ollama_data:/root/.ollama" "$OLLAMA_IMAGE" >/dev/null
}
launch_controller() {
  if start_existing "$CONTROLLER"; then return; fi
  volume "${PROJECT}_board_data"
  podman run -d --name "$CONTROLLER" --label io.conflux.stack=v0.4 \
    --network "$NETWORK" --security-opt=no-new-privileges \
    --env-file .local/worker.env --env-file .local/controller.env \
    -e VOS_BOARD_DB=/data/board.sqlite3 \
    -v "${PROJECT}_board_data:/data" "$CONTROLLER_IMAGE" coordinator.py serve >/dev/null
}
launch_worker() {
  local n="$1" name; name="$(worker_for "$n")"
  if start_existing "$name"; then return; fi
  podman run -d --name "$name" --label io.conflux.stack=v0.4 \
    --network "$NETWORK" --security-opt=no-new-privileges \
    --env-file .local/worker.env --env-file "agents/node$n.env" \
    -e VOS_NODE="$n" -e "VOS_OLLAMA_URL=http://${OLLAMA}:11434" \
    "$(image_for "$n")" transport.py worker --node "$n" >/dev/null
}
launch_webui() {
  if start_existing "$WEBUI"; then return; fi
  volume "${PROJECT}_webui_data"
  podman run -d --name "$WEBUI" --label io.conflux.stack=v0.4 \
    --network "$NETWORK" --security-opt=no-new-privileges \
    -p "127.0.0.1:${WEBUI_PORT}:8080" \
    -e "OLLAMA_BASE_URL=http://${OLLAMA}:11434" \
    -e 'DEFAULT_MODEL_PARAMS={"num_ctx":16000,"max_tokens":3000,"temperature":0.7,"think":true,"function_calling":"native"}' \
    -e WEBUI_AUTH=true \
    -v "${PROJECT}_webui_data:/app/backend/data" "$WEBUI_IMAGE" >/dev/null
}
start_all() {
  require podman
  ensure_secrets
  network
  local n
  if ! podman image exists "$CONTROLLER_IMAGE"; then
    info 'Container images are not built. Run ./install.sh first.'; exit 1
  fi
  for n in 1 2 3 4; do
    podman image exists "$(image_for "$n")" || fail "Missing image for node $n. Run ./install.sh."
  done
  launch_broker; launch_ollama
  wait_broker; wait_ollama
  launch_controller
  for n in 1 2 3 4; do launch_worker "$n"; done
  launch_webui
  info "Services running. WebUI: http://127.0.0.1:${WEBUI_PORT} ; RabbitMQ UI: http://127.0.0.1:${RABBIT_PORT}"
  info 'To enable the four named VOS chat choices, import the local Open WebUI Pipe (README Step 3).'
}
pull_models() {
  require podman
  podman container exists "$OLLAMA" || fail 'Ollama container missing. Run ./install.sh first.'
  wait_ollama
  local n model
  for model in $(for n in 1 2 3 4; do sed -n 's/^VOS_MODEL=//p' "agents/node$n.env"; done | sort -u); do
    [[ "$model" =~ ^[a-zA-Z0-9_.:/-]+$ ]] || fail 'Unsafe model name in agent profile.'
    info "Downloading Ollama model $model (existing layers will be reused)."
    podman exec "$OLLAMA" ollama pull "$model"
  done
}
status() {
  require podman
  local name
  for name in "$BROKER" "$OLLAMA" "$CONTROLLER" "$(worker_for 1)" "$(worker_for 2)" "$(worker_for 3)" "$(worker_for 4)" "$WEBUI"; do
    if managed "$name"; then
      printf '%-31s %s\n' "$name" "$(podman inspect --format '{{.State.Status}}' "$name")"
    else printf '%-31s %s\n' "$name" 'not created'; fi
  done
}
verify() {
  require podman
  local n name anybad=0
  status
  for name in "$BROKER" "$OLLAMA" "$CONTROLLER" "$(worker_for 1)" "$(worker_for 2)" "$(worker_for 3)" "$(worker_for 4)" "$WEBUI"; do
    if ! managed "$name" || [[ "$(podman inspect --format '{{.State.Running}}' "$name")" != true ]]; then
      info "NOT READY: $name"; anybad=1
    fi
  done
  [[ "$anybad" == 0 ]] || fail 'Some containers are not running.'
  podman exec "$BROKER" rabbitmq-diagnostics -q check_running || fail 'RabbitMQ health check failed.'
  podman exec "$OLLAMA" ollama list || fail 'Ollama health check failed.'
  podman exec "$CONTROLLER" python coordinator.py health || fail 'Controller health check failed.'
  info 'Container health checks passed. This does NOT verify live model inference or WebUI Pipe import.'
  info 'Next: ./vos.sh ask 1 "Say hello" and verify /board in Open WebUI.'
}
credentials() {
  [[ -f .local/controller.env && -f .local/rabbit.env ]] || fail 'Not installed. Run ./install.sh.'
  printf 'Open WebUI Pipe HARNESS_TOKEN: %s\n' "$(sed -n 's/^VOS_HARNESS_TOKEN=//p' .local/controller.env)"
  printf 'RabbitMQ user: vos_worker\nRabbitMQ password: %s\n' "$(sed -n 's/^RABBITMQ_DEFAULT_PASS=//p' .local/rabbit.env)"
  info 'Treat these as secrets. Do not paste into GitHub or chats.'
}
recreate_node() {
  local n="$1" name
  [[ "$n" =~ ^[1-4]$ ]] || fail 'Use recreate-node 1, 2, 3, or 4.'
  name="$(worker_for "$n")"
  if managed "$name"; then podman stop --ignore "$name" >/dev/null; podman rm "$name" >/dev/null; fi
  launch_worker "$n"
  info "Recreated node $n from agents/node$n.env. No saved volumes were deleted."
}
case "${1:-help}" in
  install) require podman; require python3; ensure_secrets; network; build_images; start_all; pull_models; info 'Installation provisioned; finish Open WebUI first-admin signup and Pipe import.' ;;
  start) start_all ;;
  stop) require podman; for name in "$CONTROLLER" "$(worker_for 1)" "$(worker_for 2)" "$(worker_for 3)" "$(worker_for 4)" "$WEBUI" "$OLLAMA" "$BROKER"; do stop_existing "$name"; done; info 'Stopped; all named volumes preserved.' ;;
  status) status ;;
  verify) verify ;;
  models) pull_models ;;
  rebuild) require podman; build_images; info 'Built images. Existing containers unchanged; recreate-node N to use refreshed agent images.' ;;
  recreate-node) require podman; recreate_node "${2:-}" ;;
  logs)
    require podman; which="${2:-controller}"
    case "$which" in
      controller) target="$CONTROLLER" ;;
      ollama) target="$OLLAMA" ;;
      broker) target="$BROKER" ;;
      webui) target="$WEBUI" ;;
      1|2|3|4) target="$(worker_for "$which")" ;;
      *) fail 'Use logs controller|ollama|broker|webui|1|2|3|4' ;;
    esac
    managed "$target" || fail "No managed container: $target"
    podman logs --tail 100 "$target" ;;
  board|receipts|ask)
    require podman; managed "$CONTROLLER" || fail 'Controller missing.'
    if [[ "$1" == ask ]]; then
      node="${2:-1}"; [[ "$node" =~ ^[1-4]$ ]] || fail 'Node must be 1, 2, 3, or 4.'
      [[ -n "${3:-}" ]] || fail 'Use ask NODE "prompt".'
      podman exec "$CONTROLLER" python coordinator.py ask --node "$node" "$3"
    else
      mode=notes; [[ "$1" == receipts ]] && mode=events
      podman exec "$CONTROLLER" python coordinator.py "$mode"
    fi ;;
  credentials) credentials ;;
  import-pipe) require python3; python3 scripts/import_pipe.py ;;
  help|-h|--help)
    cat <<'HELP'
Usage: ./vos.sh COMMAND
  install            Build 4 agent images + controller, deploy services, download 4B/9B
  start/stop         Run or stop ONLY the v0.4 containers (data preserved)
  verify/status      Health checks or container status
  models             Pull selected models from agents/node*.env
  ask N "prompt"    Make a live inference request through agent N
  board/receipts     Inspect real shared board / tool receipts
  logs SERVICE      controller|ollama|broker|webui|1|2|3|4
  credentials        Show local Pipe token and RabbitMQ credentials (keep private)
  import-pipe        Optional API-based Pipe import after first admin signup
  recreate-node N    Apply changed agent N environment (non-destructive)
  rebuild            Rebuild local images without replacing running containers

VOS_GPU=auto|nvidia|cpu  VOS_WEBUI_PORT=3001  VOS_RABBIT_PORT=15672
HELP
    ;;
  *) fail "Unknown command: $1. Run ./vos.sh help." ;;
esac
