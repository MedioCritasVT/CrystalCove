#!/usr/bin/env bash
set -Eeuo pipefail
target=""; apply=false
while (( $# )); do
  case "$1" in
    --target) target="${2:-}"; shift 2;;
    --apply) apply=true; shift;;
    *) echo "Usage: ./upgrade-model-routing.sh --target /path/to/EXISTING/4AgentHarness [--apply]" >&2; exit 2;;
  esac
done
[[ -n "$target" && -f "$target/vos.sh" && -d "$target/agents" ]] || { echo "Specify the actual existing harness folder with --target" >&2; exit 2; }
grep -q 'conflux_v04' "$target/vos.sh" || { echo "Not a v0.4 Conflux harness" >&2; exit 2; }
cd "$target"
models=(unused qwen3.5:9b qwen3.5:4b qwen3.5:4b qwen3.5:4b)
changed=()
for n in 1 2 3 4; do
  file="agents/node$n.env"; [[ -f "$file" ]] || exit 2
  old="$(sed -n 's/^VOS_MODEL=//p' "$file")"
  [[ -n "$old" ]] || { echo "Missing VOS_MODEL in $file" >&2; exit 2; }
  echo "Node $n: $old -> ${models[$n]}"
  [[ "$old" == "${models[$n]}" ]] || changed+=("$n")
done
if ! "$apply"; then echo "Dry run only. Repeat with --apply when ready."; exit 0; fi
(( ${#changed[@]} > 0 )) || { echo "Already configured."; exit 0; }
backup=".local/backups/routing-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$backup"; chmod 700 "$backup"
for n in 1 2 3 4; do cp "agents/node$n.env" "$backup/"; done
echo "Backed up existing model settings to $backup"
for n in "${changed[@]}"; do
  sed -i -E "s|^VOS_MODEL=.*$|VOS_MODEL=${models[$n]}|" "agents/node$n.env"
done
for n in "${changed[@]}"; do
  echo "Applying Worker $n; preserves all named volumes and Open WebUI data."
  ./vos.sh recreate-node "$n" || { echo "Worker recreation failed; restore env files from $backup and retry" >&2; exit 1; }
  podman inspect "conflux_v04_worker_$n" --format '{{range .Config.Env}}{{println .}}{{end}}' | grep -Fx "VOS_MODEL=${models[$n]}" || { echo "Worker $n model mismatch" >&2; exit 1; }
done
echo "Model routing upgraded. Test ./vos.sh ask 1 'Hello' and the actual tool receipts."
