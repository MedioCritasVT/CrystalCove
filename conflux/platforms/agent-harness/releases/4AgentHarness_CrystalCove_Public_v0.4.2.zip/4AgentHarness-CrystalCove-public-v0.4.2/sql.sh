#!/usr/bin/env bash
# Read-only local SQL access to the existing shared-board DB. No model tools.
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
command -v podman >/dev/null 2>&1 || { echo 'Podman is required.' >&2; exit 1; }
name=conflux_v04_controller
podman container exists "$name" || { echo 'VOS controller not installed; run ./install.sh first.' >&2; exit 1; }
label="$(podman inspect --format '{{index .Config.Labels "io.conflux.stack"}}' "$name")"
[[ "$label" == 'v0.4' ]] || { echo 'Refusing to inspect a container from a different stack.' >&2; exit 1; }
query="${1:-SELECT id, created_at, node, text FROM notes ORDER BY id DESC LIMIT 10}"
podman exec -i "$name" python - "$query" < scripts/sql_readonly.py
