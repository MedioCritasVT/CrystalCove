# Conflux Four-Agent Harness — v0.4.2 public candidate
Node 1: **Qwen3.5 9B**. Nodes 2–4: **Qwen3.5 4B**. One shared Ollama instance. Four isolated agent workers, RabbitMQ coordination, SQLite shared board and tool receipts, Open WebUI Pipe.
## Fresh setup
Install Podman and Python 3 on Linux, configure NVIDIA CDI if using GPU. Extract this ZIP and run `./install.sh`; then finish Open WebUI admin setup at `http://127.0.0.1:3001` and import the Pipe with `./vos.sh import-pipe`.
## Existing installation — do not reinstall
Extract this ZIP elsewhere, then run:
```bash
./upgrade-model-routing.sh --target /path/to/your/existing/4AgentHarness
./upgrade-model-routing.sh --target /path/to/your/existing/4AgentHarness --apply
```
The first command is dry-run. The second backs up the current env files and recreates only changed worker containers, **not volumes**. This does not alter your existing Open WebUI model presets.
## Import MedioCritas persona
In Open WebUI Workspace → Models → Create ▼ → Import JSON, select `examples/MedioCritas_VOS_9B_import.json`. It has a distinct ID (`mediocritas_vos_9b`) so it does not overwrite your separate direct 9B MedioCritas persona. Confirm the base model is `conflux_vos_v04.node1` before saving.
The VOS Pipe exposes only the bounded `post_note`, `read_notes`, and `ask_node` tools. It does **not** grant unrestricted SQL, Python, filesystem, Open WebUI personal-memory, VOS telemetry, or Unreal game access.
## Runtime proof
```bash
podman inspect conflux_v04_worker_1 --format '{{range .Config.Env}}{{println .}}{{end}}' | grep '^VOS_MODEL='
podman exec conflux_v04_ollama ollama ps
./vos.sh ask 1 "State which tools you can really call."
```
Inspect real controller tool receipts, not textual claims. 9B and 4B may swap in GPU memory; this does not promise concurrent inference on 12 GB VRAM.
## Scope
Public developer preview. Private per-agent persistent memory, RAG corpus, VOS service gateway, and game bridge are future proposals, **not active**. Consult docs for safety, hardware, and deployment limitations. No root project license has been selected.
