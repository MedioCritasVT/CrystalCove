"""Standalone tests for public read-only SQL inspector (no Podman required)."""
import importlib.util
from pathlib import Path
import sqlite3
import tempfile
import unittest

SOURCE = Path(__file__).resolve().parents[1] / 'scripts' / 'sql_readonly.py'
spec = importlib.util.spec_from_file_location('vos_sql_inspector', SOURCE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class SQLInspectorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)/'board.sqlite3'
        with sqlite3.connect(self.path) as conn:
            conn.execute('CREATE TABLE notes(id INTEGER PRIMARY KEY, created_at TEXT, node INTEGER, text TEXT)')
            conn.execute("INSERT INTO notes(created_at,node,text) VALUES ('now',1,'Test note')")
    def tearDown(self): self.tmp.cleanup()
    def test_select(self):
        result=mod.run('SELECT id,node,text FROM notes',str(self.path))
        self.assertEqual(result['rows'][0]['text'],'Test note')
        self.assertTrue(result['read_only'])
    def test_rejects_changes(self):
        for q in ['UPDATE notes SET text=\'oops\'','DELETE FROM notes', 'PRAGMA table_info(notes)']:
            with self.assertRaises(ValueError): mod.run(q,str(self.path))
        # A CTE that attempts to mutate or otherwise write also cannot use the RO DB.
        self.assertEqual(mod.run('SELECT count(*) AS n FROM notes',str(self.path))['rows'][0]['n'],1)

if __name__=='__main__': unittest.main()
