#!/usr/bin/env python3
"""Safe SQLite FTS5 demonstration: an IN-MEMORY sample, not the live board."""
import sqlite3

conn = sqlite3.connect(':memory:')
conn.execute('CREATE VIRTUAL TABLE knowledge USING fts5(title, body, source)')
conn.executemany('INSERT INTO knowledge(title, body, source) VALUES (?,?,?)', [
    ('VOS', 'Service observations and authenticated diagnostics may be integrated later.', 'example-vos'),
    ('Game', 'The Unreal game may emit approved events to a future gateway.', 'example-game'),
    ('Memory', 'Private per-agent memory is proposed but is not implemented in v0.4.', 'example-design'),
])
print('Example knowledge search: memory')
for title, source in conn.execute("SELECT title, source FROM knowledge WHERE knowledge MATCH ? ORDER BY rank", ('memory',)):
    print(f'- {title}: {source}')
print('No persistent database was touched.')
