# Model routing and persona setup — v0.4.2
| Node | Model | Context | Max generation | Thinking |
|---|---|---:|---:|---|
| 1 (Medio example) | qwen3.5:9b | 16000 | 3000 | true |
| 2–4 | qwen3.5:4b | 16000 | 3000 | true |

Runtime options are in `agents/nodeN.env`. Open WebUI advanced parameters do not automatically override the custom VOS Pipe's worker settings. The VOS worker has bounded tool schemas for `post_note`, `read_notes`, `ask_node` only.

For an existing v0.4 installation use `./upgrade-model-routing.sh --target /existing/path` (preview) then add `--apply` to recreate only changed worker containers. Persisted named volumes and original persona presets are not modified.

Import `examples/MedioCritas_VOS_9B_import.json` as a **new** workspace model. It routes to the 9B Node 1 harness through the Pipe; your original direct model can remain available.

12 GB GPU: default Ollama `OLLAMA_MAX_LOADED_MODELS=1`, `OLLAMA_NUM_PARALLEL=1`. This queues requests or swaps model weights rather than holding both 9B and 4B simultaneously. Test 4B parallelism separately. No live GPU acceptance claim is made.
