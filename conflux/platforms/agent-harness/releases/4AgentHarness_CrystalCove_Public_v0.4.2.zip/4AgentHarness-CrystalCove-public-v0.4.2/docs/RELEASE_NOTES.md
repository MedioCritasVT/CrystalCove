# v0.4.2 public candidate — November 12, 2026
- 9B primary on Node 1; 4B on Nodes 2–4.
- Safe in-place routing upgrade script with dry-run-first behavior and env-file backups.
- New importable MedioCritas VOS persona preset under distinct ID, preserving original personality prompt and parameters.
- Existing RabbitMQ, shared SQLite board, tools and controller remain unchanged.
- No private per-agent memory, VOS live service, RAG knowledge index or game integration is shipped.
- Test on a real target host before claiming production readiness.
