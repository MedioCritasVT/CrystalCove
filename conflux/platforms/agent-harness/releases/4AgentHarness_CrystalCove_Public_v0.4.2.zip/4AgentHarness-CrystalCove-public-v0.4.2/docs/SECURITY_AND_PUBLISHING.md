# Security, migration, and CrystalCove publication checklist

## Before uploading this bundle to a public GitHub repository

- Review every file; the **public** package intentionally excludes `original/` archives, the raw 3.5 MB user-exported JSON, private account IDs, embedded images, local `.local/` credentials, model weights, notes, chats and volume snapshots.
- Do not commit admin API keys, RabbitMQ passwords, HARNESS_TOKEN, `.env` secrets, local databases, Open WebUI user accounts, or user-specific paths.
- Do not describe v0.4 as production tested or claim VOS/game/RAG/private-memory integrations already run.
- Choose and publish a project license before inviting forks and redistribution. There is **no root LICENSE** in CrystalCove as checked during packaging; licenses of upstream tools remain separate.
- Maintain changelog and contact/security reporting route. Public GitHub visibility is not a production support or security guarantee.
- Pin tested container versions/digests before recommending unattended upgrades; current images use floating `main`/`latest` tags.

## Public-first installation safety

- All services are intended for the owner's machine; only Open WebUI (port 3001) and RabbitMQ management UI (15672) are exposed on `127.0.0.1` by default.
- Immediately configure the Open WebUI administrator account and restrict signups if this is not meant to be a multi-user local interface.
- The shared-board tools can share user-supplied text between agents and users. **Do not post secrets or private conversation data** to the board.
- The agent containers are process-isolated but **not hardened for mutually hostile users**; they share broker and controller service privileges.
- The public SQL inspection script is intentionally **read-only**, does not add an LLM SQL tool, and outputs stored data to the local terminal.
- Only model text is forwarded by the Pipe. Turning on Open WebUI capability toggles does not make host shell/file/vision access available in the harness.

## Preserve an existing v0.4 deployment

1. Keep the original installed directory, especially its `.local/` credentials. Store backups away from the public Git checkout.
2. Export any custom Open WebUI models via its UI, then review exports for account IDs, system prompts and images before sharing.
3. Back up the **four** named persistent volumes (Ollama, WebUI, RabbitMQ, board) using your host's Podman volume backup procedure. For SQLite, use a SQLite backup API or a consistent stopped-volume snapshot; do not copy a live WAL database file alone.
4. Install public source into a **separate source folder**, but do **not** start a second v0.4 stack with different credentials. Existing container names/volumes are shared by design.
5. Before `./vos.sh recreate-node N`, inspect the changes to that node's environment file. Rebuilding images does not automatically replace containers.
6. `./stop.sh` keeps volumes. No `volume rm`, pruning or database reset should be part of the normal upgrade.

## Repository placement

Recommended source tree: `conflux/platforms/agent-harness/v0.4-public/` alongside the already published v0.3 historical files. A release ZIP can be attached to a **reviewed GitHub release**, with a SHA-256 checksum. Update the platform index/README with a link only after the release asset exists and its URL works.

Do not treat a local ZIP or a draft branch as an already published download. GitHub Pages is a static website; it cannot run the Ollama/Podman stack. Visitors download and run the stack **locally** and separately from the Unreal game.
