# Changes from supplied v0.3

| Area | Supplied v0.3 | This v0.4 bundle |
| --- | --- | --- |
| Fresh installation | Requires preexisting network, 4 Ollama containers, 4 WebUIs, RabbitMQ account | Provisions its own network, RabbitMQ, one shared Ollama, one WebUI, 4 separately built agent images, controller |
| Thinking | `think: false` | `think: true` by default, configurable per agent |
| Prediction cap | 1,024 | 3,000 default, configurable per agent |
| Context | Not explicitly set in worker request | 16,000 via `options.num_ctx` and Ollama server default |
| Model assignment | One shared `VOS_MODEL`, default 4B | Four profile files: 4B,4B,9B,9B |
| Pipe authentication | Same password as RabbitMQ | Dedicated controller bearer token |
| Open WebUI | Manually update Function in each of 4 WebUIs | One WebUI exposing all four Pipe choices; optional post-admin API import |
| Queue namespace | `vos_v03_*` | `vos_v04_*`, avoids collisions |
| Controller tools | 3 tools, 4-call bound, SQLite receipts | Preserved |
| Isolation | Four Ollama endpoints | Four worker containers, shared inference endpoint (not four GPU-isolated inference instances) |
| Stop behavior | May stop legacy shared services | Stops only labeled v0.4 resources |

The old versions remain in CrystalCove historical source under `v0.3/`; the public v0.4.1 distribution excludes `original/`. No migration/merge of old boards, chats or model volumes was performed.
