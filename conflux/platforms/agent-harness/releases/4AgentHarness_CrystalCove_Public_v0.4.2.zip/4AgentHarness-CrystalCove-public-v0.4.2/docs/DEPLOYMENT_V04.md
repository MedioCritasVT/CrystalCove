> Historical v0.4 deployment guide. For the public v0.4.1 package, begin with the top-level README and check RELEASE_NOTES. The public package deliberately excludes the `original/` archive copies.

# Conflux 4AgentHarness — Podman fresh-install bundle v0.4

A standalone deployment **adapted from the supplied Conflux VOS harness v0.3**. It retains the v0.3 four-node RabbitMQ RPC, SQLite board, `post_note`, `read_notes`, `ask_node`, receipts, and bounded tool loops. It changes the default inference settings and adds **reproducible first-time provisioning**. In the original v0.4 package, files under `original/` were untouched copies from the uploaded RAR; none of the previous Podman containers or named volumes are modified.

**Status:** Code and local mock tests are included. **Not tested against a real Podman daemon, NVIDIA GPU, live Ollama model, or browser** in the packaging environment. Use `./verify.sh` and live acceptance tests on your Linux machine. A model may fail to emit a native tool call; receipts establish what actually ran.

## 1. What it creates

This is **four distinct agent images and containers**, but one shared GPU-friendly inference service (rather than four competing Ollama servers):

| Role | Image | Container |
| --- | --- | --- |
| Agent 1 | `localhost/conflux-v04-agent-1:0.4` | `conflux_v04_worker_1` |
| Agent 2 | `localhost/conflux-v04-agent-2:0.4` | `conflux_v04_worker_2` |
| Agent 3 | `localhost/conflux-v04-agent-3:0.4` | `conflux_v04_worker_3` |
| Agent 4 | `localhost/conflux-v04-agent-4:0.4` | `conflux_v04_worker_4` |
| Controller | `localhost/conflux-v04-controller:0.4` | `conflux_v04_controller` |
| Ollama | `docker.io/ollama/ollama:latest` | `conflux_v04_ollama` |
| Open WebUI | `ghcr.io/open-webui/open-webui:main` | `conflux_v04_webui` |
| RabbitMQ | `docker.io/library/rabbitmq:4-management` | `conflux_v04_rabbitmq` |

There is an additional locally built shared base image. The four agent images are individually tagged and carry distinct default node/model settings, with their common layers reused by Podman.

The private Podman network is `conflux_v04_net`. Named persistent volumes are `conflux_v04_ollama_data`, `conflux_v04_rabbit_data`, `conflux_v04_webui_data`, `conflux_v04_board_data`.

Only the browser and RabbitMQ management page are bound to **localhost** by default; the Ollama API, broker's AMQP port, and controller are not publicly exposed.

## 2. Prerequisites and first run

- A Linux host with **Podman** and **Python 3** installed, internet access to container registries, PyPI, and the Ollama registry, and enough disk space for images and model files.
- For NVIDIA GPU acceleration, a host driver that works with `nvidia-smi` and NVIDIA Container Toolkit **CDI** (check `nvidia-ctk cdi list` for `nvidia.com/gpu=all`). No Docker daemon or `podman-compose` needed.
- On a CPU-only host, the installer can run but the 9B model will be slower. For an NVIDIA system missing CDI, the auto mode deliberately falls back to CPU with a warning rather than claiming GPU use.

Unzip to a directory of your choice. In a terminal from that directory:

```bash
chmod +x *.sh
./install.sh
```

`install.sh` generates private credentials, builds the controller and **four agent images**, creates the network/volumes, starts RabbitMQ/Ollama/agents/controller/Open WebUI, and pulls both model tags. Existing matching volumes and containers are reused on repeat runs. Credential files are generated only once at `.local/` (permissions `600`) and are excluded by `.gitignore`.

GPU options (set before the first installation):

```bash
VOS_GPU=nvidia ./install.sh  # require NVIDIA CDI and fail rather than falling back
VOS_GPU=cpu ./install.sh     # intentionally CPU-only
```

`VOS_GPU=auto` is the default. The GPU choice is applied when the Ollama container is first created. It cannot be changed just by restarting that existing container.

If another app already uses host ports 3001 or 15672, set `VOS_WEBUI_PORT=3005 VOS_RABBIT_PORT=15673` at installation, and use the same port environment when accessing/importing later. Container-internal ports stay the same.

**Default browser:** http://127.0.0.1:3001  
**RabbitMQ management:** http://127.0.0.1:15672

Create the first Open WebUI admin account through the local browser, if prompted. This intentionally requires your action; no reusable default admin password is shipped.

## 3. Enable the four named agents in Open WebUI

Open WebUI runs automatically, but the **VOS Pipe Function** must be registered after the first administrator exists. This is the one normal bootstrap step that cannot be completed securely without an authorized admin account.

**Optional automated import** after creating an admin API key (Settings → Account; admin must permit API keys):

```bash
./vos.sh import-pipe
```

The script asks for your admin Open WebUI API key without echoing or persisting it. It creates and enables the `conflux_vos_v04` Function, including the dedicated controller token. It never overwrites an existing Function with that ID. API contracts can change across Open WebUI versions; use the manual fallback if the import fails.

**Manual fallback:** Open `Admin Panel → Functions`, create a new Function, paste all of `openwebui_vos_pipe.py`, save it, and enable it. Open its **admin Valves** gear and enter:

| Valve | Value |
| --- | --- |
| `HARNESS_URL` | `http://conflux_v04_controller:8080` |
| `HARNESS_TOKEN` | From `./vos.sh credentials` (dedicated Pipe token, not RabbitMQ password) |
| `TIMEOUT_SECONDS` | `960` |

Refresh the browser and select **VOS Node 1**, **2**, **3**, or **4** in the model picker. Ordinary direct Ollama models may also be visible; they do not use the 4AgentHarness's message board and peer tools. The VOS Pipe does.

## 4. Model assignments and inference parameters

Edit the corresponding file in `agents/` before installation:

| Agent | Default model | Context | Max generation | Thinking | Native tools |
| --- | --- | ---: | ---: | --- | --- |
| Node 1 | `qwen3.5:4b` | 16000 | 3000 | On | Enabled in bounded controller |
| Node 2 | `qwen3.5:4b` | 16000 | 3000 | On | Enabled in bounded controller |
| Node 3 | `qwen3.5:9b` | 16000 | 3000 | On | Enabled in bounded controller |
| Node 4 | `qwen3.5:9b` | 16000 | 3000 | On | Enabled in bounded controller |

Defaults are encoded in `agents/nodeN.env` and in the worker HTTP request to Ollama:

```json
{"think":true,"stream":false,"options":{"num_ctx":16000,"num_predict":3000,"temperature":0.7}}
```

The script sets Ollama's server default `OLLAMA_CONTEXT_LENGTH=16000`, but `options.num_ctx` on harness requests is authoritative. Open WebUI additionally receives `DEFAULT_MODEL_PARAMS` with `num_ctx=16000`, `max_tokens=3000`, `think=true`, and `function_calling=native` for **direct** model chats. A per-model or per-chat override in Open WebUI can take precedence over these WebUI defaults; the harness's worker settings remain independent.

**Important:** 3,000 is an upper bound on generation, not a guarantee of 3,000 visible answer tokens. With thinking enabled, generation and thinking may draw from the same overall token budget. Model quality and tool-call success also depend on the model and prompt. WebUI's native tool mode is not a substitute for the controller's actual allowlisted tools.

To change an agent's assigned model or generation settings **after** installation:

```bash
# Edit agents/node3.env with your editor first
./vos.sh recreate-node 3
./vos.sh models            # pulls any new model tags
```

**GPU:** To reduce VRAM collisions on a 12 GB NVIDIA card, Ollama starts with `OLLAMA_MAX_LOADED_MODELS=1`, `OLLAMA_NUM_PARALLEL=1`, and `OLLAMA_KEEP_ALIVE=2m`. All four workers can receive tasks, but Ollama serializes inference and may offload between 4B and 9B. **16,000 context with the 9B model is not guaranteed to fit entirely in 12 GB VRAM**; actual usage depends on model quantization, KV cache, driver memory, and workload. CPU offloading may occur. No GPU admission controller or deterministic performance target is promised.

## 5. Daily commands

```bash
./start.sh
./stop.sh                      # preserves every volume
./verify.sh                    # infrastructure-level health checks
./vos.sh status
./vos.sh logs 3                # worker 3 logs (or controller, broker, ollama, webui)
./vos.sh models                # download models in all four profiles
./vos.sh ask 1 'Say hello.'    # actual model test through RabbitMQ and controller
./vos.sh board                 # persistent notes, bypassing LLM narration
./vos.sh receipts              # actual tool execution receipts
./vos.sh credentials           # displays sensitive local secrets: keep private
./vos.sh help
```

No script removes volumes. The installer uses a new v0.4 naming scheme and deliberately does **not** adopt or alter legacy `ollama_node_1`–`ollama_node_4` or `vos_v03_*` containers. Stop the older system separately if it occupies ports or GPU resources.

## 6. Acceptance tests — in order

1. Run `./verify.sh`. This checks the broker, Ollama CLI, controller and container running states, but is not proof of model inference or of Pipe registration.
2. Run `./vos.sh ask 1 'State your node number in one sentence.'` and then try Node 3. These are **live** tasks, and must succeed on your host.
3. In the VOS Node 1 WebUI chat, ask: `Use post_note to save exactly COVE-V04-001 and report the note ID from the tool result.` The receipt must show `post_note` with `ok: true`.
4. In VOS Node 2, ask to `read_notes` and locate `COVE-V04-001`, then type `/board` to bypass the model and view the recorded notes directly.
5. In VOS Node 1, ask `Use ask_node to ask Node 3 for one testing suggestion.` Verify the receipt has `from_node: 3` and that the message was explicitly requested.

Live requests are non-streaming: the Pipe returns its answer and receipts after the coordinator completes. The tool loop allows up to **four tool calls per turn**, one peer answer per `ask_node` call, and at most five main inference calls. The peer has no tools. The harness does not give nodes shell access, web browsing, or unrestricted file reads.

To run the local Python unit tests in a Python environment that has `pika==1.3.2`:

```bash
python3 -m pip install pika==1.3.2
PYTHONPATH=app python3 -m unittest discover -s tests -v
```

These are mocked tests and do not replace host integration tests.

## 7. Persistence, security and limits

- **RabbitMQ:** Internal message transport, with an auto-generated `vos_worker` login. Management UI listens only on loopback. On reboot, the stored password in `.local/` must match the existing broker volume; do not delete secrets while retaining volumes.
- **Controller:** Accepts an independent bearer token from the WebUI Pipe. Only three bounded tools are executable. No container shell or host filesystem tool is available to model calls.
- **Shared board:** `board.sqlite3` lives in `conflux_v04_board_data` and is shared between all VOS agents. Notes and receipts can contain content from chats and peer requests: **not a confidential private channel**.
- **WebUI:** Login and chats are in `conflux_v04_webui_data`. Creating the first administrator is a manual step. The browser and RabbitMQ management page are bound to `127.0.0.1`, not public interfaces.
- **Source:** The `original/` directory preserves the uploaded files, and `.local/` is intentionally not distributed. Avoid accidentally committing any secret-containing files.
- **Isolation:** Separate agent processes and queues are useful operational boundaries, but all workers share the broker, model endpoint, and controller. Do **not** treat this as adversarial multi-tenant isolation.
- **Tools:** At-least-once delivery. Retry after a timeout can duplicate notes. No durable full job log, cancellation, code execution, arbitrary tool access, or automatic background tasks. No image/audio processing in the VOS Pipe (text only). There is no auto-restart/systemd policy in this version.

## Sources for compatibility settings

- Ollama Qwen3.5 model family: https://ollama.com/library/qwen3.5
- Ollama connection and reasoning defaults in Open WebUI: https://docs.openwebui.com/getting-started/quick-start/connect-a-provider/starting-with-ollama/
- Open WebUI native tool calling: https://docs.openwebui.com/features/extensibility/plugin/tools/
- Open WebUI default model parameters: https://docs.openwebui.com/reference/env-configuration/
- NVIDIA CDI and Podman: https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/cdi-support.html
- Open WebUI Functions: https://docs.openwebui.com/features/extensibility/plugin/functions/

**Reproducibility caveat:** The Ollama and WebUI container tags in this starter bundle are intentionally configurable and not digest-pinned. Pin exact tested version tags or digests after a successful host deployment, then rebuild/recreate with an explicit migration plan for stored data.
