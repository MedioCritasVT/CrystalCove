# SQL, RabbitMQ, Git and RAG: four separate responsibilities

**Present implementation:** the controller uses SQLite (`/data/board.sqlite3` on the `conflux_v04_board_data` Podman volume) to store two tables: `notes(id, created_at, node, text)` and `events(id, created_at, request_id, node, tool, result)`. These are **shared** local records, not private memory. RabbitMQ is a message broker between the controller and four workers. GitHub is a versioned source/document repository. There is no general project-file retriever exposed to the model yet.

## The simplest working SQL experience

```bash
./sql.sh
./sql.sh 'SELECT node, count(*) AS notes FROM notes GROUP BY node'
./sql.sh 'SELECT id, created_at, tool FROM events ORDER BY id DESC LIMIT 10'
```

`sql.sh` runs a Python SQLite **read-only connection** inside the controller container, limits output to 100 rows and refuses non-SELECT/CTE queries. It does not grant the LLM access to SQL and cannot mutate schema or stored records. Be mindful that notes and events may contain chat text or private details: only run locally, do not paste unreviewed output into public issues or Git.

For a safe full-text-search experiment, run:

```bash
python3 examples/fts5_demo.py
```

This uses an in-memory SQLite FTS5 index populated with three fabricated sample records, not your live board. SQLite FTS5 can support full-text document retrieval without a separate service. When real RAG is designed, the index must keep source IDs, provenance, document versions, access scopes, timestamps and deletion behavior. Search results should be quoted or cited as source material, not treated as new system instructions.

## Why RabbitMQ is NOT the RAG database

RabbitMQ is suitable for **delivering tasks, notifications, and retrieval results**. An agent can publish a request such as `knowledge.search` and a separate authorized retrieval worker could look up SQL/FTS5 records and respond with cited snippets. But RabbitMQ queues are not an authoritative searchable knowledge corpus; messages may be consumed, retried, duplicated, expired or routed to different subscribers.

Suggested future flow:

```text
GitHub / VOS document / approved game event
  -> ingestion worker (verify source + version + ACL)
  -> SQLite knowledge tables + FTS5 (persistent searchable corpus)
  -> RabbitMQ event: "index updated"

Agent asks a question
  -> bounded retrieval tool, authenticated and scoped
  -> SQL search + source snippets, source IDs and timestamps
  -> context supplied to model as untrusted evidence
  -> model answer with attribution and uncertainty
```

**Git remains useful:** Git tracks which version of a document is official and which decisions were approved. SQL indexes what may be searched locally. RabbitMQ conveys that something changed. Model inference interprets retrieved context. None of these automatically confers authorization to edit the original documents or the game.

## Future private memory: design, NOT implemented

Private memory should have an agent-id owner, access scope (`private`, `shared`, `public`), source reference, validity/revision, timestamps, author, visibility to the Architect, review state and deletion history. The harness—not a prompt—must enforce identity and access control. For a single-machine prototype, dedicated SQLite files per agent or a carefully constrained authenticated DB access layer are both possible; plain `WHERE node_id = ...` in model-generated SQL is **not** a sufficient security boundary.

A memory-manager UI should offer review, correction, export/import, explicit publish-to-shared, and protected backup. Nothing in this package silently enables agent-side memory writes or personal knowledge ingestion. A future migration needs opt-in and a reversible database migration plan.

## Scale

SQLite is a good default for one machine and modest write throughput. If CrystalCove eventually supports many users across hosts, consider PostgreSQL for authenticated, concurrent multi-user storage. That is a later architectural choice, not a prerequisite for today's prototype.

Background reading: https://www.sqlite.org/fts5.html and https://www.rabbitmq.com/tutorials/tutorial-one-python.
