# Planned VOS / game service integration (no live integration shipped)

This public harness is a **local** four-agent experiment. It is neither the VOS observation service nor an Unreal game daemon. The existing CrystalCove records include `conflux/platforms/vos/VOS_Harness_Integration_Plan_2026-10-30.md` and the simulated `CFX-M001` contract. Treat those as design references with their own approval boundaries.

## Proposed integration phases

1. **Read-only observation:** A future VOS gateway emits authenticated, versioned snapshots or events. Agents can request a specific snapshot, see when it was measured, distinguish measured data from story metaphors, and cite the source. No host shell or game control.
2. **Independent deliberation:** A workflow asks two agents the same question without giving them each other's conclusions. Once both have responded, compare claims, evidence, incompatible premises, and what would falsify each view. Produce a structured report; do not force consensus.
3. **Propose, never auto-approve:** Agents can submit attributed, inspectable VOS or game change proposals to an approval inbox. Proposal is not execution or official canon.
4. **Approved, bounded actions:** Only after separate review should a narrow action API permit limited changes, with audit logs, revocation, and rollback.
5. **Game integration:** An Unreal bridge might submit events such as a realm transition or NPC interaction to an adapter. It should receive schema-validated dialogue or suggestions, not arbitrary commands. Game state and saves remain authoritative within the game.

## Interface requirements before building adapters

- Document an API contract for event names, schema versions, sources, identities, and scopes.
- Authenticate both sides; do not expose RabbitMQ's management port, the controller or the inference endpoint on the public internet by default.
- Implement permissions and approval gates in code, not in system prompts.
- Keep deterministic gameplay and player saves functional if the AI subsystem is offline.
- Bound latency, timeouts, retries, duplicate event handling and invalid messages.
- Separate temporary conversational context from historical SQL records and from current verified telemetry.
- Add tests using simulated sources; no simulated data should be described as live telemetry.

## What this public release guarantees

It includes the current shared board, request-response exchange and a SQL inspection tool. It **does not** supply a VOS connector, game plugin, file watcher, Git sync, document ingestion worker, private-memory subsystem, or two-perspective workflow controller. Those are future proposals and require explicit design approval and implementation tests.
