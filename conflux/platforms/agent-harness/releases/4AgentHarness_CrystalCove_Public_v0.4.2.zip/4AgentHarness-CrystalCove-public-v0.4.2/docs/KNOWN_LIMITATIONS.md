# Validation and limitations

## Verified during packaging
- Uploaded RAR file inventory was CRC/size-compared to prior v0.4 ZIP: 46 files matched; the two hidden ignore files were restored from the prior package. No original v0.2/v0.3 copies are shipped in this public bundle.
- Python source syntax and unit tests using mocks.
- Bash script syntax.
- Four separately built agent image configurations are described in the build scripts.

## Not verified in packaging environment
- Running Podman images or interacting with a Podman daemon (unavailable here).
- Host NVIDIA CDI, GPU offloading, 9B + 16k context memory fit, or real performance.
- Docker/Podman image pulls and RabbitMQ container runtime API behavior.
- Actual Ollama model pull, chat, native Qwen tool emission, thought separation, or inference quality.
- Open WebUI Pipe UI registration or admin API compatibility against installed version.
- Successful live peer request after container start.

## Safe next checks on user host
1. `./install.sh` and inspect any failures; do not delete volumes to troubleshoot.
2. `./verify.sh`; `./vos.sh logs broker` or `./vos.sh logs ollama` for errors.
3. `./vos.sh ask 1 'Hello'` and `./vos.sh ask 3 'Hello'`.
4. Register the Pipe, then test receipts, `/board`, and `ask_node` one at a time.
5. If GPU offload appears absent, inspect `nvidia-ctk cdi list`, `podman inspect conflux_v04_ollama`, `nvidia-smi`, and Ollama logs; do not assume NVIDIA use from model speed alone.
